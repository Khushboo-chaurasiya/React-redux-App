import React, { useState } from 'react'
import {connect} from 'react-redux';

function EmployeeList(props) {
    const [DashBoardPage] = useState([
            {
                  "id": 1,
                  "name": "test1",
                  "age": "11",
                  "gender": "male",
                  "email": "test1@gmail.com",
                  "phoneNo": "9415346313"
            },
            {
                  "id": 2,
                  "name": "test2",
                  "age": "12",
                  "gender": "male",
                  "email": "test2@gmail.com",
                  "phoneNo": "9415346314"
            },
            {
                  "id": 3,
                  "name": "test3",
                  "age": "13",
                  "gender": "male",
                  "email": "test3@gmail.com",
                  "phoneNo": "9415346315"
            },
            {
                  "id": 4,
                  "name": "test4",
                  "age": "14",
                  "gender": "male",
                  "email": "test4@gmail.com",
                  "phoneNo": "9415346316"
            },
            {
                  "id": 5,
                  "name": "test5",
                  "age": "15",
                  "gender": "male",
                  "email": "test5@gmail.com",
                  "phoneNo": "9415346317"
            },
            {
                  "id": 6,
                  "name": "test6",
                  "age": "16",
                  "gender": "male",
                  "email": "test6@gmail.com",
                  "phoneNo": "9415346318"
            }
      ]
    );

    
    return (
        <div>
            <p className="paraCSS App">
                &nbsp;
                <span className="Left">Welcome {props.username}</span>
                <span className="Right">{props.username}</span>
            </p>
             {
                 <React.Fragment>
                 <div className='App'>
                 <h3>List of Users : </h3>
                 
                 </div>
             <table className="table table-striped App">
                 <thead>
                 <tr>
                     <th>ID</th>
                     <th>Name</th>
                     <th>Age</th>
                     <th>Gender</th>
                     <th>Email</th>
                     <th>Phone</th>
                 </tr>
                 </thead>
                 <tbody>
                 
                    {
                        DashBoardPage.map(item => (
                            <tr key={item.id}>
                            <td> {item.id} </td>
                            <td> {item.name} </td>
                            <td> {item.age} </td>
                            <td> {item.gender} </td>
                            <td>{item.email}</td>
                            <td>{item.phoneNo}</td>
                            </tr>
                        ))
                 }
                 
                 </tbody>
             </table>
             </React.Fragment>
             }
        </div>
    )
}

const mapStateToProps = state => {
    return{
      username : state.username
    }
}

export default connect(mapStateToProps)(EmployeeList);

