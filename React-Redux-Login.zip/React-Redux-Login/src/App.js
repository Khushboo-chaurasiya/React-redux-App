import React from 'react';
import './App.css';

import RouterPage from './RouterPage';

function App() {
  return (
    <div>
      <RouterPage />
    </div>
  );
}

export default App;
